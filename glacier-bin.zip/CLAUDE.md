# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Commands

```sh
npm run dev                          # Vite dev server
npm run build                        # tsc --noEmit (type-check incl. tests) + vite build -> dist/
npm run preview                      # serve dist/ (verifies the relative base path)
npm test                             # vitest run (all tests)
npx vitest run src/codec.test.ts     # single test file
npx vitest run -t "round-trips"      # single test by name
```

There is no linter/formatter configured; `npm run build` is the type-check gate. CI (`.github/workflows/deploy.yml`) runs `npm ci`, `npm test`, `npm run build`, then deploys `dist/` to GitHub Pages on push to `main` (Pages source must be set to "GitHub Actions").

## Architecture

Glacier Bin is a static, backend-less pastebin: the entire snippet lives in the URL query string. Vanilla TypeScript + Vite + CodeMirror 6, no UI framework.

**Link format (`src/codec.ts`)** — `?v=1&d=<base64url(deflate-raw(JSON {c, l, t?}))>` using the browser's native `CompressionStream`. This is a public, persistent contract: already-shared links must keep decoding. Any change to the payload shape needs a new `FORMAT_VERSION` while still accepting old versions. `decodePaste` throws `LinkError` only, whose message is shown verbatim in the error panel; decompression is capped at `MAX_DECODED_BYTES` to defuse crafted "zip bomb" links. `buildShareUrl` takes an optional base URL so it is testable outside the browser.

**App state machine (`src/main.ts`)** — one page with modes `loading | compose | view | error`, stored on `<body data-mode>`. CSS (`src/style.css`) shows/hides buttons tagged `data-mode="compose|view"` from that attribute, and hides `.shell` while `loading`. The same CodeMirror instance is reused across modes (read-only toggled via a compartment). URL changes use `history.replaceState` only — the app never pushes history entries.

Things that are easy to break:
- **Share must call `copyText` synchronously in the click/keydown handler**, passing the URL as a *promise* (`ClipboardItem` with a pending blob). Awaiting anything before starting the clipboard write breaks copying in Safari. `ui.test.ts` asserts this.
- `editor.setCode()` fires the change listener, which schedules the debounced compose update (size meter + draft autosave). That callback must re-check `mode === 'compose'` because loading a shared link or sharing also calls `setCode`.
- Drafts (`localStorage` key `glacier-bin:draft`) are restored only when opening the bare URL, and cleared on successful share or confirmed Clear. All storage access must stay wrapped in try/catch.

**Languages (`src/languages.ts`)** — `LANGUAGES` holds display names that must exactly match a `name` (or alias) in `@codemirror/language-data` (e.g. it's `diff`, lowercase); `languages.test.ts` enforces this. Language modes are lazy-loaded chunks, so `setLanguage` can reject and ignores stale results.

**Theme** — colors are defined twice: CSS custom properties in `src/style.css` for the page, and the CodeMirror editor theme + syntax `HighlightStyle` in `src/theme.ts`. Keep the cold dark-blue palette consistent across both.

**Icons (`src/icons.ts`)** — Font Awesome Free (solid) icons, but *without* the Font Awesome runtime: `iconSvg()` builds the `<svg>` from the icon definition's path data (sized by the `.icon` class in `style.css`). In `index.html`, place `<span data-icon="name"></span>`; `renderIcons()` fills them at startup. To use a new icon, import it and add it to the `ICONS` map — `icons.test.ts` fails if `index.html` references an unknown name. Text that JS rewrites at runtime (Clear button label, language badge, toast) lives in a separate span so the icon isn't wiped.

**Deployment** — `vite.config.ts` uses `base: './'` so the build works under any GitHub Pages sub-path; keep asset references in `index.html` relative.
