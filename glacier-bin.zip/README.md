# Glacier Bin

A client-side-only pastebin for sharing short code snippets. There is no server and no storage: the snippet is compressed and stored in the link's query string.

## How links work

```
https://<host>/<path>/?v=1&d=<payload>
```

- `v`: link format version (currently `1`)
- `d`: `base64url(deflate-raw(JSON))`, where the JSON is `{ "c": code, "l": language, "t"?: title }`

Compression uses the browser's built-in `CompressionStream`. Links longer than about 8,000 characters get a warning, because some chat apps and servers cut long URLs off.

> Query strings can show up in browser history and server logs. Don't share secrets.

## Development

```sh
npm install
npm run dev       # start the dev server
npm run build     # type-check and build to dist/
npm run preview   # serve the production build
npm test          # run the unit tests (Vitest)
```

Built with Vite, TypeScript and CodeMirror 6. Language modes are loaded only when needed.

## Deployment

`.github/workflows/deploy.yml` runs the tests, builds the site and publishes it to GitHub Pages on every push to `main`. You can also start it by hand.

One-time setup: in the repository, go to **Settings → Pages → Build and deployment → Source** and choose **GitHub Actions**.

The build uses a relative base path (`base: './'`), so it works under any Pages sub-path, such as `/glacier-bin/`, without changing the config.
