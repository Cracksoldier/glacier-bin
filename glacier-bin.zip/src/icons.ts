import {
  faCircleCheck,
  faCircleExclamation,
  faCode,
  faCodeFork,
  faCopy,
  faEraser,
  faFileLines,
  faIcicles,
  faLink,
  faLock,
  faPlus,
  faShareNodes,
  type IconDefinition,
} from '@fortawesome/free-solid-svg-icons';

// Only the icons listed here end up in the bundle.
const ICONS = {
  check: faCircleCheck,
  clear: faEraser,
  code: faCode,
  copy: faCopy,
  error: faCircleExclamation,
  file: faFileLines,
  fork: faCodeFork,
  icicles: faIcicles,
  link: faLink,
  lock: faLock,
  new: faPlus,
  share: faShareNodes,
} satisfies Record<string, IconDefinition>;

export type IconName = keyof typeof ICONS;

export function isIconName(name: string | undefined): name is IconName {
  return name !== undefined && Object.hasOwn(ICONS, name);
}

// Builds the SVG directly from the icon's path data instead of shipping the
// Font Awesome runtime; sizing/alignment comes from the .icon class in style.css.
export function iconSvg(name: IconName): string {
  const [width, height, , , path] = ICONS[name].icon;
  const paths = (Array.isArray(path) ? path : [path]).map((d) => `<path fill="currentColor" d="${d}"/>`).join('');
  return `<svg class="icon" viewBox="0 0 ${width} ${height}" aria-hidden="true" focusable="false">${paths}</svg>`;
}

/** Replaces every `<span data-icon="name">` placeholder in the page with its SVG. */
export function renderIcons(root: ParentNode = document): void {
  for (const el of root.querySelectorAll<HTMLElement>('[data-icon]')) {
    const name = el.dataset.icon;
    if (!isIconName(name)) continue;
    el.innerHTML = iconSvg(name);
    el.setAttribute('aria-hidden', 'true');
  }
}
