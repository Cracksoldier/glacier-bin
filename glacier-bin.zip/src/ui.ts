import { iconSvg } from './icons';

export const URL_WARN_LENGTH = 8000;
export const URL_DANGER_LENGTH = 32000;

export function $<T extends HTMLElement>(id: string): T {
  const el = document.getElementById(id);
  if (!el) throw new Error(`Missing element #${id}`);
  return el as T;
}

let toastTimer: number | undefined;

export function toast(message: string, isError = false): void {
  const el = $('toast');
  el.innerHTML = iconSvg(isError ? 'error' : 'check');
  const text = document.createElement('span');
  text.textContent = message;
  el.append(text);
  el.classList.toggle('error', isError);
  el.classList.add('show');
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => el.classList.remove('show'), 2400);
}

/**
 * Copies text to the clipboard. Call this synchronously from the user's event
 * handler: the text may be a promise, so Safari (which requires the clipboard
 * write to start within the user gesture) still accepts it after async work.
 */
export async function copyText(text: string | Promise<string>): Promise<boolean> {
  if (typeof ClipboardItem !== 'undefined' && navigator.clipboard?.write) {
    try {
      const blob = Promise.resolve(text).then((t) => new Blob([t], { type: 'text/plain' }));
      await navigator.clipboard.write([new ClipboardItem({ 'text/plain': blob })]);
      return true;
    } catch {
      // Fall through to the simpler APIs below.
    }
  }
  const value = await text;
  try {
    await navigator.clipboard.writeText(value);
    return true;
  } catch {
    // Fallback for browsers/contexts without the async clipboard API.
    const ta = document.createElement('textarea');
    ta.value = value;
    ta.style.position = 'fixed';
    ta.style.opacity = '0';
    document.body.appendChild(ta);
    ta.select();
    const ok = document.execCommand('copy');
    ta.remove();
    return ok;
  }
}

export function formatBytes(n: number): string {
  return n < 1024 ? `${n} B` : `${(n / 1024).toFixed(1)} KB`;
}

export function renderSize(urlLength: number | null): void {
  const wrap = $('size-wrap');
  const el = $('size');
  wrap.classList.remove('warn', 'danger');
  wrap.hidden = urlLength === null;
  if (urlLength === null) return;
  let note = '';
  if (urlLength > URL_DANGER_LENGTH) {
    wrap.classList.add('danger');
    note = ' — too long for many apps';
  } else if (urlLength > URL_WARN_LENGTH) {
    wrap.classList.add('warn');
    note = ' — may be cut off in some apps';
  }
  el.textContent = `link: ${urlLength.toLocaleString()} chars${note}`;
}

export function renderStats(code: string): void {
  const lines = code === '' ? 0 : code.split('\n').length;
  const bytes = new TextEncoder().encode(code).length;
  $('stats').textContent = `${lines} ${lines === 1 ? 'line' : 'lines'} · ${formatBytes(bytes)}`;
}

const DRAFT_KEY = 'glacier-bin:draft';

export interface Draft {
  code: string;
  language: string;
  title: string;
}

// Storage can be unavailable (private mode, blocked site data), so every access is guarded.
export function loadDraft(): Draft | null {
  try {
    const raw = localStorage.getItem(DRAFT_KEY);
    if (!raw) return null;
    const d = JSON.parse(raw) as Partial<Draft>;
    if (typeof d.code !== 'string') return null;
    return {
      code: d.code,
      language: typeof d.language === 'string' ? d.language : '',
      title: typeof d.title === 'string' ? d.title : '',
    };
  } catch {
    return null;
  }
}

export function saveDraft(draft: Draft): void {
  try {
    if (!draft.code && !draft.title) localStorage.removeItem(DRAFT_KEY);
    else localStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
  } catch {
    // Ignore: drafts are a convenience only.
  }
}

export function clearDraft(): void {
  try {
    localStorage.removeItem(DRAFT_KEY);
  } catch {
    // Ignore.
  }
}
