import { EditorView } from '@codemirror/view';
import { HighlightStyle, syntaxHighlighting } from '@codemirror/language';
import { tags as t } from '@lezer/highlight';

const c = {
  bg: '#0d1526',
  gutter: '#0a1120',
  text: '#dbe7f5',
  muted: '#5b6f8f',
  selection: '#1f3a5f',
  cursor: '#5ccfe6',
  activeLine: '#111d33',
  cyan: '#5ccfe6',
  blue: '#7aa2f7',
  teal: '#73daca',
  violet: '#a9b1ff',
  frost: '#b4f9f8',
  ice: '#9ecbff',
  slate: '#6b7fa3',
  coral: '#f7768e',
  sand: '#e0c989',
};

export const glacierEditorTheme = EditorView.theme(
  {
    '&': { color: c.text, backgroundColor: c.bg, height: '100%' },
    '.cm-scroller': {
      fontFamily: 'var(--font-mono)',
      fontSize: '14px',
      lineHeight: '1.6',
    },
    '.cm-content': { caretColor: c.cursor, padding: '14px 0' },
    '.cm-cursor, .cm-dropCursor': { borderLeftColor: c.cursor, borderLeftWidth: '2px' },
    '&.cm-focused > .cm-scroller > .cm-selectionLayer .cm-selectionBackground, .cm-selectionBackground, ::selection':
      { backgroundColor: c.selection },
    '.cm-activeLine': { backgroundColor: c.activeLine },
    '.cm-gutters': {
      backgroundColor: c.gutter,
      color: c.muted,
      border: 'none',
      borderRight: '1px solid #1a2740',
    },
    '.cm-activeLineGutter': { backgroundColor: c.activeLine, color: c.cyan },
    '.cm-lineNumbers .cm-gutterElement': { padding: '0 12px 0 16px' },
    '.cm-matchingBracket, .cm-nonmatchingBracket': {
      backgroundColor: '#1d3350',
      outline: '1px solid #2e5179',
    },
    '.cm-placeholder': { color: c.muted, fontStyle: 'italic' },
    '&.cm-focused': { outline: 'none' },
  },
  { dark: true },
);

const glacierHighlight = HighlightStyle.define([
  { tag: [t.keyword, t.modifier, t.controlKeyword, t.operatorKeyword], color: c.blue },
  { tag: [t.definitionKeyword, t.moduleKeyword], color: c.violet },
  { tag: [t.function(t.variableName), t.function(t.propertyName)], color: c.cyan },
  { tag: [t.string, t.special(t.string), t.regexp], color: c.teal },
  { tag: [t.number, t.bool, t.null, t.atom], color: c.sand },
  { tag: [t.typeName, t.className, t.namespace], color: c.frost },
  { tag: [t.propertyName, t.attributeName], color: c.ice },
  { tag: [t.comment, t.lineComment, t.blockComment], color: c.slate, fontStyle: 'italic' },
  { tag: [t.tagName], color: c.blue },
  { tag: [t.operator, t.punctuation, t.bracket], color: '#89a4c7' },
  { tag: [t.variableName], color: c.text },
  { tag: [t.definition(t.variableName)], color: '#cfe3ff' },
  { tag: [t.heading], color: c.cyan, fontWeight: 'bold' },
  { tag: [t.link, t.url], color: c.teal, textDecoration: 'underline' },
  { tag: [t.emphasis], fontStyle: 'italic' },
  { tag: [t.strong], fontWeight: 'bold' },
  { tag: [t.inserted], color: c.teal },
  { tag: [t.deleted, t.invalid], color: c.coral },
  { tag: [t.meta, t.processingInstruction], color: c.slate },
]);

export const glacierTheme = [glacierEditorTheme, syntaxHighlighting(glacierHighlight)];
