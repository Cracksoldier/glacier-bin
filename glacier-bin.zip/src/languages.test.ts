import { describe, expect, it } from 'vitest';
import { findLanguage, LANGUAGES, PLAIN_TEXT } from './languages';

describe('LANGUAGES', () => {
  it('has no duplicates', () => {
    expect(new Set(LANGUAGES).size).toBe(LANGUAGES.length);
  });

  it.each(LANGUAGES.filter((l) => l !== PLAIN_TEXT))('%s resolves to a CodeMirror language', (name) => {
    expect(findLanguage(name)).toBeDefined();
  });
});
