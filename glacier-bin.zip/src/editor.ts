import { basicSetup } from 'codemirror';
import { Compartment, EditorState } from '@codemirror/state';
import { EditorView, keymap, placeholder } from '@codemirror/view';
import { indentWithTab } from '@codemirror/commands';
import { glacierTheme } from './theme';
import { loadLanguage } from './languages';

export interface Editor {
  view: EditorView;
  getCode(): string;
  setCode(code: string): void;
  setLanguage(name: string): Promise<void>;
  setReadOnly(readOnly: boolean): void;
}

export function createEditor(parent: HTMLElement, onChange: () => void): Editor {
  const language = new Compartment();
  const readOnly = new Compartment();
  let languageRequest = 0;

  const view = new EditorView({
    parent,
    state: EditorState.create({
      extensions: [
        basicSetup,
        keymap.of([indentWithTab]),
        glacierTheme,
        placeholder('Paste or type your snippet here…'),
        EditorView.contentAttributes.of({ 'aria-label': 'Code snippet' }),
        language.of([]),
        readOnly.of([]),
        EditorView.updateListener.of((u) => {
          if (u.docChanged) onChange();
        }),
      ],
    }),
  });

  return {
    view,
    getCode: () => view.state.doc.toString(),
    setCode(code) {
      view.dispatch({ changes: { from: 0, to: view.state.doc.length, insert: code } });
    },
    async setLanguage(name) {
      const request = ++languageRequest;
      let support;
      try {
        support = await loadLanguage(name);
      } catch (err) {
        if (request === languageRequest) throw err;
        return;
      }
      // Ignore stale results if the user switched languages again meanwhile.
      if (request !== languageRequest) return;
      view.dispatch({ effects: language.reconfigure(support ?? []) });
    },
    setReadOnly(value) {
      view.dispatch({
        effects: readOnly.reconfigure(value ? [EditorState.readOnly.of(true), EditorView.editable.of(false)] : []),
      });
    },
  };
}
