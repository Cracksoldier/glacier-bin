import { languages as languageData } from '@codemirror/language-data';
import type { LanguageDescription, LanguageSupport } from '@codemirror/language';

export const PLAIN_TEXT = 'Plain text';

// Names as listed in @codemirror/language-data, shown in this order.
export const LANGUAGES = [
  PLAIN_TEXT,
  'JavaScript',
  'TypeScript',
  'JSX',
  'TSX',
  'Python',
  'Rust',
  'Go',
  'Java',
  'Kotlin',
  'C#',
  'C',
  'C++',
  'PHP',
  'Ruby',
  'Swift',
  'Shell',
  'PowerShell',
  'SQL',
  'JSON',
  'YAML',
  'TOML',
  'XML',
  'HTML',
  'CSS',
  'SCSS',
  'Markdown',
  'Dockerfile',
  'Lua',
  'diff',
];

export function findLanguage(name: string): LanguageDescription | undefined {
  return languageData.find((l) => l.name === name || l.alias.includes(name.toLowerCase()));
}

export async function loadLanguage(name: string): Promise<LanguageSupport | null> {
  if (name === PLAIN_TEXT) return null;
  const desc = findLanguage(name);
  return desc ? desc.load() : null;
}
