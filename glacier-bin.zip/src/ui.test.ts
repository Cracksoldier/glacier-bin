import { afterEach, beforeEach, describe, expect, it, vi } from 'vitest';
import { clearDraft, copyText, formatBytes, loadDraft, saveDraft } from './ui';

afterEach(() => {
  vi.unstubAllGlobals();
});

describe('copyText', () => {
  it('starts the clipboard write synchronously even when the text is still pending', async () => {
    const write = vi.fn((_items: unknown[]) => Promise.resolve());
    vi.stubGlobal('navigator', { clipboard: { write, writeText: vi.fn() } });
    vi.stubGlobal(
      'ClipboardItem',
      class {
        constructor(public items: Record<string, Promise<Blob>>) {}
      },
    );

    let resolve!: (s: string) => void;
    const pending = new Promise<string>((r) => (resolve = r));
    const result = copyText(pending);

    // Safari only allows the write if it begins inside the user gesture, i.e. before any await.
    expect(write).toHaveBeenCalledTimes(1);

    resolve('https://example.com/?d=x');
    expect(await result).toBe(true);
    const item = write.mock.calls[0][0][0] as { items: Record<string, Promise<Blob>> };
    expect(await (await item.items['text/plain']).text()).toBe('https://example.com/?d=x');
  });

  it('falls back to writeText when ClipboardItem is unavailable', async () => {
    const writeText = vi.fn(() => Promise.resolve());
    vi.stubGlobal('ClipboardItem', undefined);
    vi.stubGlobal('navigator', { clipboard: { writeText } });

    expect(await copyText(Promise.resolve('hello'))).toBe(true);
    expect(writeText).toHaveBeenCalledWith('hello');
  });
});

describe('drafts', () => {
  beforeEach(() => {
    const store = new Map<string, string>();
    vi.stubGlobal('localStorage', {
      getItem: (k: string) => store.get(k) ?? null,
      setItem: (k: string, v: string) => void store.set(k, v),
      removeItem: (k: string) => void store.delete(k),
    });
  });

  it('saves and restores a draft', () => {
    saveDraft({ code: 'print(1)', language: 'Python', title: 'demo' });
    expect(loadDraft()).toEqual({ code: 'print(1)', language: 'Python', title: 'demo' });
  });

  it('removes the draft when it is empty or cleared', () => {
    saveDraft({ code: 'x', language: 'Go', title: '' });
    saveDraft({ code: '', language: 'Go', title: '' });
    expect(loadDraft()).toBeNull();

    saveDraft({ code: 'x', language: 'Go', title: '' });
    clearDraft();
    expect(loadDraft()).toBeNull();
  });

  it('ignores corrupt stored data', () => {
    localStorage.setItem('glacier-bin:draft', '{not json');
    expect(loadDraft()).toBeNull();
  });

  it('survives storage that throws', () => {
    vi.stubGlobal('localStorage', {
      getItem: () => {
        throw new Error('blocked');
      },
      setItem: () => {
        throw new Error('blocked');
      },
      removeItem: () => {
        throw new Error('blocked');
      },
    });
    expect(() => saveDraft({ code: 'x', language: 'Go', title: '' })).not.toThrow();
    expect(() => clearDraft()).not.toThrow();
    expect(loadDraft()).toBeNull();
  });
});

describe('formatBytes', () => {
  it('formats bytes and kilobytes', () => {
    expect(formatBytes(512)).toBe('512 B');
    expect(formatBytes(2048)).toBe('2.0 KB');
  });
});
