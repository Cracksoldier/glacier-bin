import './style.css';
import { buildShareUrl, decodePaste, encodePaste, LinkError, type Paste } from './codec';
import { createEditor } from './editor';
import { renderIcons } from './icons';
import { LANGUAGES, PLAIN_TEXT } from './languages';
import { $, clearDraft, copyText, loadDraft, renderSize, renderStats, saveDraft, toast } from './ui';

type Mode = 'loading' | 'compose' | 'view' | 'error';

const titleInput = $<HTMLInputElement>('title');
const titleView = $<HTMLHeadingElement>('title-view');
const languageSelect = $<HTMLSelectElement>('language');
const languageWrap = $('language-wrap');
const languageBadge = $('language-badge');
const editorPanel = $('editor-panel');
const errorPanel = $('error-panel');
const statusbar = $('statusbar');
const meta = $('meta');
const clearButton = $<HTMLButtonElement>('btn-clear');
const clearLabel = $('clear-label');

renderIcons();

let mode: Mode = 'loading';
let composeTimer: number | undefined;

const editor = createEditor($('editor'), () => {
  renderStats(editor.getCode());
  scheduleComposeUpdate();
});

for (const name of LANGUAGES) {
  languageSelect.add(new Option(name, name));
}

function currentPaste(): Paste {
  return {
    code: editor.getCode(),
    language: languageSelect.value,
    title: titleInput.value.trim() || undefined,
  };
}

function setMode(next: Mode): void {
  mode = next;
  document.body.dataset.mode = next;
  const viewing = next === 'view';
  const failed = next === 'error';

  editorPanel.hidden = failed;
  statusbar.hidden = failed;
  meta.hidden = failed;
  errorPanel.hidden = !failed;

  titleInput.hidden = viewing;
  titleView.hidden = !viewing;
  languageWrap.hidden = viewing;
  languageBadge.hidden = !viewing;
  editor.setReadOnly(viewing);
  resetClearButton();
}

// Debounced work while composing: link-size meter and draft autosave.
function scheduleComposeUpdate(): void {
  window.clearTimeout(composeTimer);
  composeTimer = window.setTimeout(async () => {
    if (mode !== 'compose') return;
    const paste = currentPaste();
    saveDraft({ code: paste.code, language: paste.language, title: titleInput.value });
    if (!paste.code) return renderSize(null);
    const size = buildShareUrl(await encodePaste(paste)).length;
    if (mode === 'compose') renderSize(size);
  }, 250);
}

function applyLanguage(name: string): void {
  editor.setLanguage(name).catch((err: unknown) => {
    console.error(err);
    toast(`Couldn't load ${name} highlighting. Check your connection and try again.`, true);
  });
}

function loadIntoEditor(paste: Paste): void {
  const language = LANGUAGES.includes(paste.language) ? paste.language : PLAIN_TEXT;
  languageSelect.value = language;
  titleInput.value = paste.title ?? '';
  editor.setCode(paste.code);
  applyLanguage(language);
}

function showView(paste: Paste): void {
  loadIntoEditor(paste);
  titleView.textContent = paste.title || 'Untitled snippet';
  $('language-badge-text').textContent = languageSelect.value;
  document.title = paste.title ? `${paste.title} · Glacier Bin` : 'Glacier Bin';
  setMode('view');
  renderSize(window.location.href.length);
}

function startCompose(paste?: Paste): void {
  loadIntoEditor(paste ?? { code: '', language: PLAIN_TEXT });
  document.title = 'Glacier Bin';
  setMode('compose');
  renderStats(editor.getCode());
  scheduleComposeUpdate();
  editor.view.focus();
}

function resetUrl(): void {
  const url = new URL(window.location.href);
  url.search = '';
  url.hash = '';
  history.replaceState(null, '', url);
}

function share(): void {
  const paste = currentPaste();
  if (!paste.code.trim()) {
    toast('Nothing to share yet — add some code first.', true);
    return;
  }
  const urlPromise = encodePaste(paste).then((data) => buildShareUrl(data));
  // Start the clipboard write synchronously, inside the user gesture (required by Safari).
  const copied = copyText(urlPromise);
  void (async () => {
    let url: string;
    try {
      url = await urlPromise;
    } catch (err) {
      console.error(err);
      toast('Could not create a link for this snippet.', true);
      return;
    }
    history.replaceState(null, '', url);
    clearDraft();
    showView(paste);
    toast((await copied) ? 'Link copied to clipboard ❄' : 'Link ready — copy it from the address bar.');
  })();
}

// Clear asks for a second click instead of discarding work immediately.
let clearArmedTimer: number | undefined;

function resetClearButton(): void {
  window.clearTimeout(clearArmedTimer);
  delete clearButton.dataset.armed;
  clearLabel.textContent = 'Clear';
}

function onClear(): void {
  const isEmpty = !editor.getCode() && !titleInput.value;
  if (isEmpty || clearButton.dataset.armed) {
    clearDraft();
    startCompose();
    return;
  }
  clearButton.dataset.armed = 'true';
  clearLabel.textContent = 'Click again to clear';
  window.clearTimeout(clearArmedTimer);
  clearArmedTimer = window.setTimeout(resetClearButton, 3000);
}

async function init(): Promise<void> {
  const params = new URLSearchParams(window.location.search);
  const data = params.get('d');
  if (!data) {
    const draft = loadDraft();
    startCompose(draft ? { code: draft.code, language: draft.language, title: draft.title } : undefined);
    return;
  }
  try {
    showView(await decodePaste(data, params.get('v')));
  } catch (err) {
    console.error(err);
    if (err instanceof LinkError) $('error-message').textContent = err.message;
    setMode('error');
  }
}

// ---------- events ----------
languageSelect.addEventListener('change', () => {
  applyLanguage(languageSelect.value);
  scheduleComposeUpdate();
});
titleInput.addEventListener('input', scheduleComposeUpdate);

$('btn-share').addEventListener('click', share);
clearButton.addEventListener('click', onClear);
$('btn-copy-code').addEventListener('click', async () => {
  const ok = await copyText(editor.getCode());
  toast(ok ? 'Code copied' : 'Copy failed', !ok);
});
$('btn-copy-link').addEventListener('click', async () => {
  const ok = await copyText(window.location.href);
  toast(ok ? 'Link copied ❄' : 'Copy failed', !ok);
});
$('btn-fork').addEventListener('click', () => {
  const paste = currentPaste();
  resetUrl();
  startCompose(paste);
});
const startNew = (): void => {
  resetUrl();
  startCompose();
};
$('btn-new').addEventListener('click', startNew);
$('btn-error-new').addEventListener('click', startNew);
$('brand').addEventListener('click', (e) => {
  e.preventDefault();
  // In compose mode the logo must not discard the current work.
  if (mode === 'compose') editor.view.focus();
  else startNew();
});

document.addEventListener('keydown', (e) => {
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
    e.preventDefault();
    if (mode === 'compose') share();
  }
});

void init();
