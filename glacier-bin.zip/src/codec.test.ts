import { describe, expect, it } from 'vitest';
import { buildShareUrl, decodePaste, encodePaste, FORMAT_VERSION, LinkError, MAX_DECODED_BYTES } from './codec';

async function rawPayload(json: string): Promise<string> {
  const stream = new Blob([json]).stream().pipeThrough(new CompressionStream('deflate-raw'));
  const bytes = new Uint8Array(await new Response(stream).arrayBuffer());
  return btoa(String.fromCharCode(...bytes)).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

describe('encodePaste / decodePaste', () => {
  it('round-trips code, language and title including non-ASCII text', async () => {
    const paste = { code: 'fn main() {\n    println!("Grüße ❄ 🧊");\n}\n', language: 'Rust', title: 'héllo' };
    const data = await encodePaste(paste);
    expect(await decodePaste(data, FORMAT_VERSION)).toEqual(paste);
  });

  it('omits the title when empty', async () => {
    const data = await encodePaste({ code: 'x', language: 'Plain text' });
    expect(await decodePaste(data, FORMAT_VERSION)).toEqual({ code: 'x', language: 'Plain text', title: undefined });
  });

  it('produces URL-safe output without padding', async () => {
    const data = await encodePaste({ code: '?&=/+'.repeat(200) + crypto.randomUUID(), language: 'Go' });
    expect(data).toMatch(/^[A-Za-z0-9_-]+$/);
  });

  it('accepts links without a version parameter', async () => {
    const data = await encodePaste({ code: 'a', language: 'Python' });
    expect((await decodePaste(data, null)).code).toBe('a');
  });

  it('rejects unsupported versions', async () => {
    const data = await encodePaste({ code: 'a', language: 'Python' });
    await expect(decodePaste(data, '99')).rejects.toThrow(LinkError);
    await expect(decodePaste(data, '99')).rejects.toThrow(/unsupported format version/);
  });

  it('rejects truncated payloads with a LinkError', async () => {
    const data = await encodePaste({ code: 'const answer = 42;\n'.repeat(20), language: 'JavaScript' });
    await expect(decodePaste(data.slice(0, -8), FORMAT_VERSION)).rejects.toThrow(LinkError);
  });

  it('rejects invalid base64 with a LinkError', async () => {
    await expect(decodePaste('!!not base64!!', FORMAT_VERSION)).rejects.toThrow(LinkError);
  });

  it('rejects payloads without a code field', async () => {
    await expect(decodePaste(await rawPayload('{"l":"Go"}'), FORMAT_VERSION)).rejects.toThrow(/does not contain/);
    await expect(decodePaste(await rawPayload('null'), FORMAT_VERSION)).rejects.toThrow(/does not contain/);
  });

  it('falls back to plain text when the language is missing', async () => {
    const paste = await decodePaste(await rawPayload('{"c":"hi"}'), FORMAT_VERSION);
    expect(paste.language).toBe('Plain text');
  });

  it('refuses payloads that decompress beyond the size limit', async () => {
    const bomb = await rawPayload(JSON.stringify({ c: 'a'.repeat(MAX_DECODED_BYTES * 4), l: 'Go' }));
    // The compressed link itself is tiny compared to what it expands to.
    expect(bomb.length).toBeLessThan(20_000);
    await expect(decodePaste(bomb, FORMAT_VERSION)).rejects.toThrow(/too large/);
  });
});

describe('buildShareUrl', () => {
  it('replaces existing query and hash while keeping the path', () => {
    const url = new URL(buildShareUrl('abc', 'https://example.github.io/glacier-bin/?v=1&d=old#x'));
    expect(url.pathname).toBe('/glacier-bin/');
    expect(url.hash).toBe('');
    expect([...url.searchParams]).toEqual([
      ['v', FORMAT_VERSION],
      ['d', 'abc'],
    ]);
  });
});
