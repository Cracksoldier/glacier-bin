// Encodes a paste into a compact, URL-safe string and back.
// Format v1: base64url(deflate-raw(JSON.stringify({ c, l, t? })))

export const FORMAT_VERSION = '1';

// Upper bound for decompressed payloads. Deflate can expand ~1000x, so a
// crafted link must not be able to allocate unbounded memory in the tab.
export const MAX_DECODED_BYTES = 1024 * 1024;

export interface Paste {
  code: string;
  language: string;
  title?: string;
}

interface Wire {
  c: string;
  l: string;
  t?: string;
}

/** An error whose message is safe and meaningful to show to the user. */
export class LinkError extends Error {
  override name = 'LinkError';
}

async function pipe(
  data: Uint8Array,
  stream: CompressionStream | DecompressionStream,
  maxBytes = Infinity,
): Promise<Uint8Array> {
  const reader = new Blob([data as BlobPart]).stream().pipeThrough(stream).getReader();
  const chunks: Uint8Array[] = [];
  let total = 0;
  for (;;) {
    const { done, value } = await reader.read();
    if (done) break;
    total += value.length;
    if (total > maxBytes) {
      await reader.cancel().catch(() => {});
      throw new LinkError('The snippet in this link is too large to open.');
    }
    chunks.push(value);
  }
  const out = new Uint8Array(total);
  let offset = 0;
  for (const chunk of chunks) {
    out.set(chunk, offset);
    offset += chunk.length;
  }
  return out;
}

function toBase64Url(bytes: Uint8Array): string {
  let bin = '';
  for (let i = 0; i < bytes.length; i += 0x8000) {
    bin += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  }
  return btoa(bin).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
}

function fromBase64Url(s: string): Uint8Array {
  const b64 = s.replace(/-/g, '+').replace(/_/g, '/');
  const bin = atob(b64 + '='.repeat((4 - (b64.length % 4)) % 4));
  const bytes = new Uint8Array(bin.length);
  for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
  return bytes;
}

export async function encodePaste(paste: Paste): Promise<string> {
  const wire: Wire = { c: paste.code, l: paste.language };
  if (paste.title) wire.t = paste.title;
  const json = new TextEncoder().encode(JSON.stringify(wire));
  return toBase64Url(await pipe(json, new CompressionStream('deflate-raw')));
}

export async function decodePaste(data: string, version: string | null): Promise<Paste> {
  if (version !== null && version !== FORMAT_VERSION) {
    throw new LinkError(`This link uses an unsupported format version ("${version}").`);
  }
  let wire: Partial<Wire> | null;
  try {
    const bytes = await pipe(fromBase64Url(data), new DecompressionStream('deflate-raw'), MAX_DECODED_BYTES);
    wire = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(bytes)) as Partial<Wire> | null;
  } catch (err) {
    if (err instanceof LinkError) throw err;
    throw new LinkError('The snippet in this link could not be decoded. It may have been truncated when copied.');
  }
  if (typeof wire?.c !== 'string') throw new LinkError('This link does not contain a snippet.');
  return {
    code: wire.c,
    language: typeof wire.l === 'string' ? wire.l : 'Plain text',
    title: typeof wire.t === 'string' ? wire.t : undefined,
  };
}

export function buildShareUrl(data: string, base: string = window.location.href): string {
  const url = new URL(base);
  url.search = '';
  url.hash = '';
  url.searchParams.set('v', FORMAT_VERSION);
  url.searchParams.set('d', data);
  return url.toString();
}
