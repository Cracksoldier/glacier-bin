import { describe, expect, it } from 'vitest';
import html from '../index.html?raw';
import { iconSvg, isIconName } from './icons';

describe('icons', () => {
  const used = [...html.matchAll(/data-icon="([^"]+)"/g)].map((m) => m[1]);

  it('index.html uses icons', () => {
    expect(used.length).toBeGreaterThan(0);
  });

  it.each([...new Set(used)])('"%s" is a known icon', (name) => {
    expect(isIconName(name)).toBe(true);
  });

  it('renders an accessible-hidden SVG with currentColor paths', () => {
    const svg = iconSvg('copy');
    expect(svg).toMatch(/^<svg class="icon" viewBox="0 0 \d+ \d+" aria-hidden="true"/);
    expect(svg).toContain('fill="currentColor"');
  });

  it('rejects unknown and inherited names', () => {
    expect(isIconName('nope')).toBe(false);
    expect(isIconName('toString')).toBe(false);
    expect(isIconName(undefined)).toBe(false);
  });
});
